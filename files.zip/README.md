# Oyun Yayıncısı - Ana Sayfa (MIREVOX)

Bu proje, bir oyun yayıncısının kişisel ana sayfasıdır ve modern, şık bir arayüz ile oyun topluluğuna hitap etmektedir. TailwindCSS ile tasarlanmış, tam responsive ve Türkçe dilindedir.

## Özellikler

- **Navigasyon:** Sabit üst menü, mobil ve masaüstü için uygun tasarım.
- **Hero Bölümü:** Tiping animasyonu, canlı yayın bağlantısı ve hızlı tanışma butonu.
- **Hakkımda:** Yayıncı hakkında detaylı bilgi ve istatistikler.
- **Oyunlar:** Oynanan oyun kategorileri hakkında öne çıkan kartlar.
- **İletişim:** Bağlantı linkleri ve mesaj formu (form, demo amaçlıdır; mesajlar backend'e gönderilmez).
- **Footer:** Marka ve telif bilgisi.

## Kullanılan Teknolojiler

- **HTML5**
- **TailwindCSS**
- **Vanilla JavaScript**

## Hızlı Başlangıç

1. **Projeyi klonlayın:**
    ```sh
    git clone https://github.com/mehmetistan05-png/My.website.git
    ```
2. **`index.html` dosyasını bir tarayıcıda açın.**

## Özelleştirme

- `index.html` dosyasında sosyal medya bağlantılarınızı, oyun listenizi ve kişisel bilgilerinizi güncelleyebilirsiniz.
- Tasarım tamamen özelleştirilebilir ve yeni bölümler kolayca eklenebilir.

## Ekran Görüntüsü

_Aşağıda örnek bir görünüm:_

![Ekran Görüntüsü](screenshot.png)

## Canlı Yayın ve Sosyal Medya

- [Kick: mirevox](https://kick.com/mirevox)
- [YouTube: mirevox](https://youtube.com/@mirevox?si=If9HOvxQAGQaqP3l)

## Katkıda Bulunma

Pull request'ler ve öneriler her zaman açıktır! Lütfen önce bir issue açarak neyi değiştirmek istediğinizi belirtin.

## Lisans

© 2024 MIREVOX. Tüm hakları saklıdır.
